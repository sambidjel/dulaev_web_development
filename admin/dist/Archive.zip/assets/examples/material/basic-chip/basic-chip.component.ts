import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-chip',
  templateUrl: './basic-chip.component.html',
  styleUrls: ['./basic-chip.component.scss']
})
export class BasicChipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
