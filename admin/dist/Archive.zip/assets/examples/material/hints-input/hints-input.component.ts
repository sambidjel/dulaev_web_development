import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hints-input',
  templateUrl: './hints-input.component.html',
  styleUrls: ['./hints-input.component.scss']
})
export class HintsInputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
