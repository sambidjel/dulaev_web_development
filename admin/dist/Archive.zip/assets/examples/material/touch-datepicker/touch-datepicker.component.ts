import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-touch-datepicker',
  templateUrl: './touch-datepicker.component.html',
  styleUrls: ['./touch-datepicker.component.scss']
})
export class TouchDatepickerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
