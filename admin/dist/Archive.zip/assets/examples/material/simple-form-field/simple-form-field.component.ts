import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-form-field',
  templateUrl: './simple-form-field.component.html',
  styleUrls: ['./simple-form-field.component.scss']
})
export class SimpleFormFieldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
