import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hints-form-field',
  templateUrl: './hints-form-field.component.html',
  styleUrls: ['./hints-form-field.component.scss']
})
export class HintsFormFieldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
