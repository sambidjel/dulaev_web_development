import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-two-sidenav',
  templateUrl: './two-sidenav.component.html',
  styleUrls: ['./two-sidenav.component.scss']
})
export class TwoSidenavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
