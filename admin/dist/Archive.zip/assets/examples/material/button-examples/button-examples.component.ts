import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-button-examples',
  templateUrl: './button-examples.component.html',
  styleUrls: ['./button-examples.component.scss']
})
export class ButtonExamplesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
