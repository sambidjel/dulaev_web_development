import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multi-section-card',
  templateUrl: './multi-section-card.component.html',
  styleUrls: ['./multi-section-card.component.scss']
})
export class MultiSectionCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
